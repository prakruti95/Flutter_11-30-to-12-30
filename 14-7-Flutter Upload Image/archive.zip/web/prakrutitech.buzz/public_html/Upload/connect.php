<?php

    define('HOST','localhost');
    define('USER','prak230_prakruti');
    define('PASS','Tops@123');
    define('DB','prak230_test');

    $con = mysqli_connect(HOST,USER,PASS,DB) or die('unable to connect');


?>
